################################################
# Data Science Essentials in R: Data Preparation
#
# UVA Library Research Data Services
# January 29, 2019
# Michele Claibourn
# 
# 1. Data source
# 2. Load library, set working directory, read in data sets: read_csv, select, mutate
# 3. Merge data sets: join, filter, select
# 4. Initial look at key variables: filter, select, arrange, (very little) ggplot
# 5. Munge data: filter, select, mutate, if_else, factors
# 6. Clean up and save: rm, save.image, saveRDS, write_csv
# 7. Explore data, answer questions: group_by, summarize, filter, arrange, etc.
################################################

################################################
# # 1. Data source
# # Data located and acquired by Clay Ford
# # You don't need to run this... 
# # ...the resulting data files are part of our workshop materials.
# #
# # Albmarle county Office of Geographic Data Services
# # http://www.albemarle.org/department.asp?department=gds&relpage=3914#Parcels
# 
# # Real Estate Information - Primary Card Level Data 
# # http://www.albemarle.org/gds/gisdata/CAMA/CAMA_CardLevelData_TXT.zip
# 
# link <- "http://www.albemarle.org/gds/gisdata/CAMA/CAMA_CardLevelData_TXT.zip"
# download.file(link, destfile = basename(link))
# unzip(basename(link), list = TRUE) # list files, but don't extract
# unzip(basename(link), "CAMA_CardLevelData.txt") # extract file to working directory
# card_level <- read.csv("CAMA_CardLevelData.txt", stringsAsFactors = FALSE)
# names(card_level)
# 
# # Real Estate Information - Parcel Level Data.  
# # http://www.albemarle.org/gds/gisdata/CAMA/CAMA_ParcelInfo_TXT.zip
# 
# link2 <- "http://www.albemarle.org/gds/gisdata/CAMA/CAMA_ParcelInfo_TXT.zip"
# download.file(link2, destfile = basename(link2))
# unzip(basename(link2), list = TRUE) # list files, but don't extract
# unzip(basename(link2), "CAMA_ParcelInfo.txt") # extract file to working directory
# parcel_level <- read.csv("CAMA_ParcelInfo.txt", stringsAsFactors = FALSE)


################################################
# 2. Load library, set working directory, read in data sets ----

library(tidyverse)
library(lubridate)

setwd("~/Box Sync/AC_homes/dataprepR/") # change me!

# a.  read in card level data and have a peek
card_level <- read_csv("CAMA_CardLevelData.txt")
str(card_level)
summary(card_level)

# list of variables to keep
vars <- c("TMP", "CardNum", "CardType", "YearBuilt", "YearRemodeled", "UseCode", 
          "Condition", "NumStories", "FinSqFt", "Cooling", "FP_Num", 
          "Bedroom", "FullBath", "HalfBath", "TotalRooms"
          )
# select listed variables, add variable for source
card <- card_level %>% 
  select(vars) %>% 
  mutate(source = "card")

# b. read in parcel level data and have a peek
parcel_level <- read_csv("CAMA_ParcelInfo.txt")
str(parcel_level)
summary(parcel_level)

# list of variables to keep
vars <- c("ParcelID", "Owner", "City", "Zip", "LotSize", "PropName",
          "LandValue", "LandUseValue", "ImprovementsValue", 
          "TotalValue", "LastSalePrice", "LastSaleDate", 
          "Subdivision", "Cards"
          )

## YOUR TURN: finish this step
# select listed variables, add variable for source = parcel
parcel <- parcel_level %>% 


rm(card_level, parcel_level)


################################################
# 3. merge primary card level data with parcel level data ---- 

n_distinct(card$TMP)
n_distinct(parcel$ParcelID)

homes <- full_join(card, parcel, by = c("TMP" = "ParcelID"))

# check the result
# records in parcels only
in_parcel <- homes %>% 
  filter(is.na(source.x)) %>% 
  select(Owner:Cards)
View(in_parcel)

# many with 0 improvements (or missing), how many?
in_parcel %>% 
  filter(ImprovementsValue == 0 | is.na(ImprovementsValue)) %>% 
  tally()

# records in cards only
in_cards <- homes %>% 
  filter(is.na(source.y)) %>% 
  select(TMP:TotalRooms)
View(in_cards)
# mostly vacant residential land or use is missing

## YOUR TURN: finish this step
# keep only records in both cards and parcels
homes <- homes %>% 

  
# and make a copy in case we mess something up or want to reference the full set
homes_copy <- homes
rm(in_parcel, in_cards)


################################################
# 4. Initial look at key variables ----

# a. keep only residential home records (e.g., not businesses, apartment complexes)
#    ideally, home properties which individual households own, and with which they 
#    can accrue wealth, or properties that can be rented to individual households 

table(homes$UseCode)

# identify residential home records with UseCode 
res <- c("Doublewide", "Duplex", "Mobile Homes", 
         "Rental House", "Single Family", "Single Family-Rental"
         )

homes <- homes %>% 
  filter(UseCode %in% res)


# b. examine key variables: TotalValue, LandValue, FinSqFt, LotSize, ImprovementsValue
# TotalValue
summary(homes$TotalValue) # 2 NAs, some 0s, and more than 200M at max

homes %>%  # check NAs
  filter(is.na(TotalValue)) %>% 
  select(CardType, UseCode, FinSqFt, LotSize, LandValue, ImprovementsValue, TotalValue)

homes %>% # check 0s
  filter(TotalValue == 0) %>% 
  select(CardType, UseCode, FinSqFt, LotSize, LandValue, ImprovementsValue) 

# remove the rows with TotalValue 0 or NA
homes <- homes %>% filter(!is.na(TotalValue) & TotalValue > 0)

ggplot(homes, aes(x = TotalValue)) + geom_histogram()
ggplot(homes, aes(log(TotalValue))) + geom_histogram()


# LandValue
summary(homes$LandValue)

homes %>% # check 0s
  filter(LandValue == 0) %>% 
  select(UseCode, Owner, FinSqFt, LotSize, ImprovementsValue, TotalValue)
# all but one are owned by communication companies; related to towers (rather than land), I think...

# remove the rows with LandValue 0
homes <- homes %>% 
  filter(LandValue > 0)

ggplot(homes, aes(LandValue)) + geom_histogram()
ggplot(homes, aes(log(LandValue))) + geom_histogram()


# FinSqFt
summary(homes$FinSqFt) # 9 NAs, some 0s, and up to nearly 20K sqft

tmp <- homes %>% # check NAs (I want to see the full Owner/Name so save in tmp data frame)
  filter(is.na(FinSqFt)) %>% 
  select(YearBuilt, UseCode, FinSqFt, TotalRooms, Owner, LotSize, PropName, LandValue, ImprovementsValue, TotalValue)
# some commercial, all duplex/rental (remove below)

tmp <- homes %>% # check 0s
  filter(FinSqFt == 0) %>% 
  select(YearBuilt, UseCode, FinSqFt, TotalRooms, Owner, LotSize, PropName, LandValue, ImprovementsValue, TotalValue) %>% 
  arrange(desc(ImprovementsValue))

tmp %>% 
  filter(ImprovementsValue > 75000) %>% 
  tally()
# outside of the first 100+, most don't seem to have improvements valued highly enough to be a home (remove below)

# check the high end
tmp <- homes %>% 
  filter(FinSqFt > 5000) %>% 
  select(YearBuilt, UseCode, FinSqFt, TotalRooms, Owner, City, LotSize:TotalValue, Cards) %>% 
  arrange(desc(FinSqFt)) # limit this, e.g, < 10K

# remove rows with FinSqFt >= 10000
homes <- homes %>% 
  filter(!is.na(FinSqFt) & FinSqFt > 0 & FinSqFt < 10000)

ggplot(homes, aes(x = FinSqFt)) + geom_histogram(binwidth = 100) 


# LotSize
summary(homes$LotSize)

tmp <- homes %>% # check 0s
  filter(LotSize == 0) %>% 
  arrange(FinSqFt)
# mostly condos/townhouses, keep

tmp <- homes %>%  # check high end
  filter(LotSize > 250) %>% 
  arrange(desc(LotSize))
# mostly farms (also golf course, school, ashlawn, etc.)
# ... many with mutiple properties on one assessment

# remove records with 2 or more cards associated with parcel
homes <- homes %>% 
  filter(Cards < 2)

ggplot(homes, aes(LotSize)) + geom_histogram()
ggplot(filter(homes, LotSize > 0), aes(log(LotSize))) + geom_histogram()


# ImprovementsValue
summary(homes$ImprovementsValue)

## YOUR TURN: finish the steps
# create a tmp file with ImprovementsValue == 0, arrange the file by FinSqFt
tmp <- homes %>% 


ggplot(homes, aes(ImprovementsValue)) + geom_histogram()
ggplot(homes, aes(log(ImprovementsValue))) + geom_histogram()



################################################
# 5. Munge remaining data ---- 

# CardType
table(homes$CardType)
homes %>% 
  filter(CardType == "C") %>% 
  select(YearBuilt, UseCode, FinSqFt, TotalRooms, Owner, ImprovementsValue) 
homes <- homes %>% filter(CardType == "R") %>% # keep only R
  select(-CardType) # and remove column

# YearBuilt
summary(homes$YearBuilt) # check 0s
tmp <- homes %>% 
  filter(YearBuilt == 0) %>% 
  arrange(LastSaleDate)
# just missing on these; use with caution
ggplot(filter(homes, YearBuilt > 0), aes(x = YearBuilt)) + geom_histogram()

# UseCode
table(homes$UseCode) # consider reducing to just single family...

# Condition**
table(homes$Condition) # reformat as factor
cond_levels <- c("Substandard", "Poor", "Fair", "Average", "Good", "Excellent") # define levels/order
homes <- homes %>% 
  mutate(condition = factor(Condition, levels = cond_levels)) # I created a new variable here
summary(homes$condition)

# redo - recode missing to None and use as a level
cond_levels <- c("None", "Substandard", "Poor", "Fair", "Average", "Good", "Excellent")
homes <- homes %>% 
  mutate(Condition = if_else(is.na(Condition), "None", Condition),
         condition = factor(Condition, levels = cond_levels)) %>% 
  select(-Condition) # remove old variable
summary(homes$condition)

# NumStories
table(homes$NumStories) # realize I don't know what this means; was expecting 1, 2, 3, etc.. Let's drop it
homes <- homes %>% select(-NumStories)

# Cooling, FP_Num**
table(homes$Cooling) # make a factor
homes <- homes %>% 
  mutate(Cooling = factor(Cooling, levels = c("No Central Air", "Central Air")))

table(homes$FP_Num) # make a binary indicator
homes <- homes %>% 
  mutate(fp = if_else(FP_Num > 0, 1, 0))

# Bedroom, FullBath, HalfBath, TotalRooms 
table(homes$Bedroom) # 228 homes with no bedroom seems high, use with caution
table(homes$FullBath) # 263 homes with no full bath seems high, use with caution
table(homes$HalfBath) # ok
table(homes$TotalRooms) # 1310 homes with no rooms is definitely a coding error, use with caution

# City**
table(homes$City) 
sum(is.na(homes$City)) # 256 missing
# based on mailing address, not jurisdictional boundaries,
# let's keep labels for those with > ~400 records and combine the remainder
homes <- homes %>% mutate(city = fct_explicit_na(City),
                          city = fct_lump(city, n = 9, other_level = "OTHER"),
                          city = fct_infreq(city),
                          city = fct_relevel(city, "OTHER", after = Inf))
table(homes$city)

# Zip 
summary(homes$Zip) # 256 missing
table(homes$City, homes$Zip) # basically replicates City

# LandUseValue
summary(homes$LandUseValue)
homes <- homes %>% # create binary indicator for land use
  mutate(landuse = if_else(LandUseValue > 0, 1, 0)) %>% 
  select(-LandUseValue) # remove variable
table(homes$landuse)

# LastSalePrice, LastSaleDate**
summary(homes$LastSaleDate)

summary(homes$LastSalePrice)
tmp <- homes %>% 
  filter(LastSalePrice == 0) %>% 
  arrange(LastSaleDate) # last sale date is prior to year built for many

homes %>% 
  mutate(datecheck = if_else(YearBuilt > as.integer(year(LastSaleDate)), 1, 0)) %>% 
  filter(datecheck == 1 | YearBuilt == 0) %>% 
  tally()
# so YearBuilt (or LastSaleDate) is wrong for at least 3472 records

# Subdivision 
table(homes$Subdivision) # would need more work and understanding to be useful
homes <- homes %>% 
  select(-Subdivision)

# Remove Owner, PropName, souce.x, source.y -- these were for examining the data
homes <- homes %>% 
  select(-c(CardNum, Owner, source.x, source.y, PropName, Cards))


## YOUR TURN:
# How many homes were remodeled (YearRemodeled)


# Create a binary variable (remodel) that indicates if a home has been remodeled



################################################
# 6. Clean up and save ----
rm(tmp, res, vars, cond_levels)

save.image("albemarle_homes.Rdata") # save everything to working directory
# load("albemarle_homes.Rdata")

saveRDS(homes, file = "albemarle_homes.rds") # save just the homes data frame 
# readRDS("albemarle_homes.rds")

write_csv(homes, path = "albemarle_homes.csv") # save a csv file of the homes data
# homes <- read_csv("albemarle_homes.csv")


################################################
# 7. Explore data, answer questions ----

# Does average house size (FinSqFt) appear related to assessed condition (condition)?
homes %>% 
  group_by(condition) %>% 
  summarize(mean(FinSqFt))


## YOUR TURN:
# Does average property value (ImprovementsValue) apear related to assessed condition (condition)?



# Do average property value (ImprovementsValue), land value (LandValue), or 
# ... total assesed value (TotalValue) appear related to to city?


# Find the median year for building homes (YearBuilt) by city
# ... for homes where YearBuilt is available (not 0)


# Add the proportion of homes remodeled in each city and sort by this proportion


# Find the number of homes remodeled by year (YearRemodeled)
remodels <- homes %>% 
  filter(YearRemodeled > 1800) %>% 
  group_by(YearRemodeled) %>% 
  summarize(total = n())

ggplot(remodels, aes(x = YearRemodeled, y = total)) + geom_line()
