################################################
# Data Science Essentials in R: Intro to dplyr
#
# UVA Library Research Data Services
# January 29, 2019
# Michele Claibourn
# 
# Follow along with webpage examples...
# I've included some, but not all, of the
# examples in the webpage. Feel free to 
# add the others yourself. Or change them!
################################################

library(tidyverse)
homes <- read_csv("http://people.virginia.edu/~jah2ax/intro_to_R_spring_2019/albemarle_real_estate.csv")

# select
select(homes, TotalValue)
select(homes, TotalValue, City)


# filter
filter(homes, YearBuilt == 2016)
filter(homes, YearRemodeled > 0)


# arrange
arrange(homes, FinSqFt)


# pipes
homes %>% 
  filter(City == "SCOTTSVILLE") %>% 
  select(TotalValue, LotSize) %>% 
  arrange(desc(LotSize))


# mutate
homes %>% 
  mutate(value_sqft = TotalValue/FinSqFt) %>% 
  select(YearBuilt, Condition, FinSqFt, TotalValue, City, value_sqft) %>% 
  arrange(desc(value_sqft))


# summarize
homes %>% 
  summarize(oldest = min(YearBuilt), 
            newest = max(YearBuilt), 
            total = n())


# group_by
homes %>% 
  group_by(City) %>% 
  summarize(oldest = min(YearBuilt), 
            newest = max(YearBuilt), 
            total = n())


# factors
homes %>% count(Condition) # currently a character

homes %>% 
  mutate(condition = factor(Condition)) %>% # make a factor
  count(condition)

# assert the order of the factor levels
cond_levels <- c("Excellent", "Good", "Average", "Fair", "Poor", "Substandards")
homes %>% 
  mutate(condition = factor(Condition, levels = cond_levels)) %>% 
  count(condition)