# UI code for first shiny app;
# intended to be copied-and-pasted into shiny app

sliderInput("alpha", "Alpha:",
            min = 0, max = 1,
            value = 0.5, step = 0.1),
numericInput("xlim1", "xlim lower:",
             min = 0, max = max(homes$finsqft),
             value = 0, step = 1e2),
numericInput("xlim2", "xlim upper:",
             min = 0, max = max(homes$finsqft),
             value = max(homes$finsqft), step = 1e2),
numericInput("ylim1", "ylim lower:",
             min = 0, max = max(homes$totalvalue),
             value = 0, step = 1e3),
numericInput("ylim2", "ylim upper:",
             min = 0, max = max(homes$totalvalue),
             value = max(homes$totalvalue), step = 1e3)