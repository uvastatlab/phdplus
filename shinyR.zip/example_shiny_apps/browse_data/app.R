# Example of a shiny app that displays data with some filters

# based on https://shiny.rstudio.com/gallery/basic-datatable.html

library(shiny)
library(DT) # to create javascript data tables
library(tidyverse)

# read in data outside of ui and server objects.
github_url <- "https://github.com/uvastatlab/phdplus/raw/master/data/albemarle_homes.rds"
homes <- readRDS(url(github_url))


# Define UI for application 
ui <- fluidPage(
  titlePanel("Albemarle County Homes"),
  
  # Create a new Row in the UI for selectInputs;
  # a fluid-page consists of a 12-unit wide grid.
  # Below we define 3 columns, each 4-units wide.
  fluidRow(
    
    # Notice we create a new level called "All" for each input; this allows us
    # to see all levels of a particular variable.
    column(4,
           selectInput("city",
                       "City:",
                       c("All",
                         levels(homes$city)))
    ),
    column(4,
           selectInput("usecode",
                       "Use Code:",
                       c("All",
                         unique(homes$usecode)))
    ),
    column(4,
           selectInput("condition",
                       "Condition:",
                       c("All",
                         levels(homes$condition)))
    )
  ),
  # Create a new row for the table.
  dataTableOutput("table")   # from DT package
)

# Define server logic 
server <- function(input, output) {
   
  output$table <- renderDataTable(   # from DT package
    
    # we wrap the following in the datatable() function; 
    # from the DT package
    # it converts the data frame into a JavaScript DataTable
    datatable({
      
      # Everytime one of the filters changes in the UI, the following code runs.
      
      # notice we rename the homes data frame as "data"; this is so we don't
      # overwrite the original data frame
      data <- homes
      if (input$city != "All") {
        data <- data %>% filter(city == input$city)
        }
      if (input$usecode != "All") {
        data <- data %>% filter(usecode == input$usecode)
        }
      if (input$condition != "All") {
        data <- data %>% filter(condition == input$condition)
        }
      data
  })
  )
}

# Run the application 
shinyApp(ui = ui, server = server)




