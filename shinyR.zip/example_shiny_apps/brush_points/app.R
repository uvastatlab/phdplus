# example of shiny app that allows you to select points with your mouse;

# Based on https://shiny.rstudio.com/gallery/plot-interaction-selecting-points.html

# This is the same app we built in the workshop, with the ability to select
# points and have information about the points displayed

library(shiny)
library(tidyverse)
library(DT)

# load data outside of UI and server
github_url <- "https://github.com/uvastatlab/phdplus/raw/master/data/albemarle_homes.rds"
homes <- readRDS(url(github_url))


# Define UI for application 
ui <- fluidPage(
  
  # Application title
  titlePanel("TotalValue vs FinSqFt"),
  p("Click and drag over the plot to select points. The selected points will display in the table below."),
  
  # Sidebar 
  sidebarLayout(
    sidebarPanel(
      sliderInput("alpha", "Alpha:",
                  min = 0, max = 1,
                  value = 0.5, step = 0.1),
      numericInput("xlim1", "xlim lower:",
                   min = 0, max = max(homes$finsqft),
                   value = 0, step = 1e2),
      numericInput("xlim2", "xlim upper:",
                   min = 0, max = max(homes$finsqft),
                   value = max(homes$finsqft), step = 1e2),
      numericInput("ylim1", "ylim lower:",
                   min = 0, max = max(homes$totalvalue),
                   value = 0, step = 1e3),
      numericInput("ylim2", "ylim upper:",
                   min = 0, max = max(homes$totalvalue),
                   value = max(homes$totalvalue), step = 1e3)
    ),
    
    # Notice we use the brush argument; allows the user to "brush" in the
    # plotting area, and will send information about the brushed area to the
    # server, and the value will be accessible via input$scatterPlot_brush
    # ("scatterPlot_brush" is the name I picked; it can be something else)
    mainPanel(
      plotOutput("scatterPlot",
                 brush = brushOpts(
                   id = "scatterPlot_brush")
                 ),
    dataTableOutput("brush_info")   # from DT package
  )
))

# Define server logic required to draw a histogram
server <- function(input, output) {

  
  output$scatterPlot <- renderPlot({
    ggplot(homes, aes(x = finsqft, y = totalvalue)) +
      geom_point(alpha = input$alpha) +
      scale_x_continuous(labels = scales::comma) +
      scale_y_continuous(labels = scales::dollar) +
      coord_cartesian(xlim = c(input$xlim1, input$xlim2), 
                      ylim = c(input$ylim1, input$ylim2))
  })

  
  output$brush_info <- renderDataTable({   # from DT package
    datatable({   # from DT package
      
      # brushedPoints returns rows from a data frame which are under a brush
      # (ie, rows contained in input$scatterPlot_brush)
      brushedPoints(homes, input$scatterPlot_brush)
    })
  })
  
}

# Run the application 
shinyApp(ui = ui, server = server)

