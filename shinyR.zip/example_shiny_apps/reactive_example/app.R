# demonstration of reactivity

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(tabsetPanel(
  tabPanel("Without Reactivity",
   
   # Application title
   titlePanel("Example without Reactivity"),
   p("Notice that changing the checkbox for Descending results in a new sample of numbers."),
   
   # Sidebar with a slider input for sample size and checkbox for decreasing value
   sidebarLayout(
      sidebarPanel(
         sliderInput("n",
                     "Sample Size:",
                     min = 10,
                     max = 30,
                     value = 10),
         checkboxInput("desc",
                       "Sort Descending:",
                       FALSE)
      ),
      
      # Numbers
      mainPanel(
         textOutput("numbers")
      )
   )
),
tabPanel("With Reactivity",
         # Application title
         titlePanel("Example with Reactivity"),
         p("Notice that changing the checkbox for Descending", strong("DOES NOT"), "result in a new sample of numbers. The sample
           size input is captured in a reactive function; the sample only changes when the sample size changes. Checking
           and unchecking the box does not result in a new sample"),
         
         # Sidebar with a slider input for sample size and checkbox for decreasing value
         sidebarLayout(
           sidebarPanel(
             sliderInput("n2",
                         "Sample Size:",
                         min = 10,
                         max = 30,
                         value = 10),
             checkboxInput("desc2",
                           "Sort Descending:",
                           FALSE)
           ),
           
           # Numbers
           mainPanel(
             textOutput("numbers2")
           )
         ))

))

# Define server logic
server <- function(input, output) {

  # without modular reaction   
   output$numbers <- renderText({
     sort(sample(100, size = input$n), decreasing = input$desc)
   })
   
   # with modular reaction   
   re <- reactive({sample(100, size = input$n2)})
   output$numbers2 <- renderText({
     sort(re(), decreasing = input$desc2)
   })
   

}

# Run the application 
shinyApp(ui = ui, server = server)

