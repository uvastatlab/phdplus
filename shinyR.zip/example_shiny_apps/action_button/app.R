# Example of a shiny app with an action button

# based on https://shiny.rstudio.com/gallery/isolate-demo.html

# This is the same app we built in the workshop, except we have added a "plot"
# button that must be pressed to implement changes in the UI

# load our data outside of the UI and Server
library(shiny)
library(tidyverse)
github_url <- "https://github.com/uvastatlab/phdplus/raw/master/data/albemarle_homes.rds"
homes <- readRDS(url(github_url))


# Define UI for application 
ui <- fluidPage(
  
  # Application title
  titlePanel("TotalValue vs FinSqFt"),
  
  # Sidebar with a slider input 
  
  sidebarLayout(
    sidebarPanel(
      sliderInput("alpha", "Alpha:",
                  min = 0, max = 1,
                  value = 0.5, step = 0.1),
      numericInput("xlim1", "xlim lower:",
                   min = 0, max = max(homes$finsqft),
                   value = 0, step = 1e2),
      numericInput("xlim2", "xlim upper:",
                   min = 0, max = max(homes$finsqft),
                   value = max(homes$finsqft), step = 1e2),
      numericInput("ylim1", "ylim lower:",
                   min = 0, max = max(homes$totalvalue),
                   value = 0, step = 1e3),
      numericInput("ylim2", "ylim upper:",
                   min = 0, max = max(homes$totalvalue),
                   value = max(homes$totalvalue), step = 1e3),
      
      # Here is the action button!
      actionButton("plot", "Plot")
    ),
    
    # Show plot
    mainPanel(
      plotOutput("scatterPlot")
    )
  )
)

# Define server logic 
server <- function(input, output) {
  
output$scatterPlot <- renderPlot({
  
  # Adding input$plot here makes this reactive object depend on it. That
  # means when the button is pressed, the code below will re-execute.
  input$plot
  
  # Notice we have wrapped all the inputs in isolate(). This prevents them from
  # triggering the plot to get re-drawn. That will only happen if we click the
  # plot button.
  ggplot(homes, aes(x = finsqft, y = totalvalue)) +
    geom_point(alpha = isolate(input$alpha)) +
    scale_x_continuous(labels = scales::comma) +
    scale_y_continuous(labels = scales::dollar) +
    coord_cartesian(xlim = c(isolate(input$xlim1), isolate(input$xlim2)), 
                    ylim = c(isolate(input$ylim1), isolate(input$ylim2)))
  })
}

# Run the application 
shinyApp(ui = ui, server = server)

