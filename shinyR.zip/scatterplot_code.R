library(tidyverse)

github_url <- "https://github.com/uvastatlab/phdplus/raw/master/data/albemarle_homes.rds"
homes <- readRDS(url(github_url))

# look at homes in the top 6 cities by number of homes
vars <- c("CHARLOTTESVILLE", "CROZET", "EARLYSVILLE", 
          "KESWICK", "SCOTTSVILLE", "NORTH GARDEN")

# filter for our cities of interest and homes with at least 1 bedroom and 1 bathroom
homes <- homes %>% 
  filter(city %in% vars & bedroom > 0 & fullbath > 0)

# drop unusued levels for city
homes$city <- droplevels(homes$city)

# plot totalvalue vs finsqft
ggplot(homes, aes(x = finsqft, y = totalvalue)) +
  geom_point(alpha = 0.2) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_continuous(labels = scales::dollar) +
  coord_cartesian(xlim = c(1500, 3000), ylim = c(0, 5e5)) 


