# shiny exercise solution

# https://at.virginia.edu/2SS695y

library(shiny)
library(effects)
library(scales)
library(tidyverse)

github_url <- "https://github.com/uvastatlab/phdplus/raw/master/data/albemarle_homes.rds"
homes <- readRDS(url(github_url))
vars <- c("CHARLOTTESVILLE", "CROZET", "EARLYSVILLE", 
          "KESWICK", "SCOTTSVILLE", "NORTH GARDEN")
homes <- homes %>% 
  filter(city %in% vars & bedroom > 0 & fullbath > 0)
homes$city <- droplevels(homes$city)

# Fit model with FullBath and 3-way interaction between FinSqFt, city and Lot Size;
# LotSize = Deeded acreage for the parcel
mod <- lm(log(totalvalue) ~ fullbath + poly(finsqft, 3) * city * poly(lotsize, 3), data = homes)


# Define UI
ui <- fluidPage(tabsetPanel(
  tabPanel("Effects",
   
   # Application title
   titlePanel("Effect Plot"),
   p("Select which cities you want to compare. Use the Lot Size slider to set the maximum 
   values of the x axis. Use the Finished Square Ft sliders to set the minimum and/or maximum 
     values of the four Finished Square Ft groups in the effect plot. Use the Full 
     Bathrooms slider to change the assumed number of Full Bathrooms in creating the effect plots."),
   # Sidebar with a slider input for number of bins 
   sidebarLayout(
      sidebarPanel(
        checkboxGroupInput(inputId = "city", label = "city",
                           choices = c("Charlottesville" = "CHARLOTTESVILLE",
                                       "Crozet" = "CROZET",
                                       "Earlysville" = "EARLYSVILLE",
                                       "Keswick" = "KESWICK",
                                       "North Garden" = "NORTH GARDEN",
                                       "Scottsville" = "SCOTTSVILLE"),
                           selected = "CHARLOTTESVILLE"),
        sliderInput(inputId = "fsfMin", label = "Minimum Finished Sq Ft",
                    min = 300, max = 10000, value = 500, step = 50),
        sliderInput(inputId = "fsfMax", label = "Maximum Finished Sq Ft",
                    min = 300, max = 10000, value = 5000, step = 50),
        sliderInput(inputId = "lotsize", label = "Maximum Lot Size:",
                    min = 2, max = 20, value = 10, step = 0.25),
         sliderInput("fullbaths",
                     "Number of Full baths:",
                     min = 1,
                     max = 6,
                     value = 2)
      ),
      
      # Show a plot of the generated distribution
      mainPanel(
         plotOutput("effPlot")
      )
   )
), tabPanel("Estimates",
            titlePanel("Home Estimates"),
            p("Estimate the expected value of a home given the various settings below."),
            sidebarLayout(
              sidebarPanel(
                h3("A home with..."),
                sliderInput(inputId = "fullbaths2", label = "Full Bathrooms:", 
                            min = 1, max = 5, value = 2),
                numericInput(inputId = "finsqft2", "Finished Sq Ft:",
                             value = 2000, min = 500, max = 5000, step = 1),
                numericInput(inputId = "lotsize2", "Lot Size:",
                             value = 1, min = 0, max = 50, step = 0.5),
                selectInput(inputId = "city2", label = "City:", 
                            choices = c("Charlottesville" = "CHARLOTTESVILLE",
                                        "Crozet" = "CROZET",
                                        "Earlysville" = "EARLYSVILLE",
                                        "Keswick" = "KESWICK",
                                        "North Garden" = "NORTH GARDEN",
                                        "Scottsville" = "SCOTTSVILLE"))
              ),
              mainPanel(wellPanel(
                h3("...has an expected value of about"),
                h3(textOutput("estimate"))
              )
              )
            ))))

# Define server logic
server <- function(input, output) {
   
  
  # reactive for creating effect dataframe
  re <- reactive({
    effDF <- as.data.frame(Effect(c("lotsize","finsqft","city"), mod = mod, 
                                  xlevels = list(lotsize = seq(0,input$lotsize,length.out = 20), 
                                                 finsqft = round(seq(input$fsfMin,input$fsfMax,length.out = 4))),
                                  fixed.predictors = list(given.values = c(fullbath = input$fullbaths))))
    
  }) 
  
   output$effPlot <- renderPlot({
     yaxs <- select(re(), lower, upper) %>% exp() %>% range() %>% pretty()
     filter(re(), city %in% input$city) %>% 
       ggplot(aes(x = lotsize, y = fit, color = factor(finsqft))) +
       geom_line() +
       geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 1/5) + 
       facet_wrap(~city) +
       scale_y_continuous(breaks = log(yaxs),
                          labels = dollar(yaxs)) +
       scale_color_discrete("Finished Sq Ft", 
                            guide = guide_legend(reverse = TRUE)) +
       ylab("Total Value") +
       xlab("Lot Size") +
       theme_bw()
   })
   
   output$estimate <- renderText({
     pred <- round(exp(predict(mod, newdata = data.frame(fullbath = input$fullbaths2, 
                                                         lotsize = input$lotsize2,
                                                         city = input$city2,
                                                         finsqft = input$finsqft2))))
     dollar(pred)
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

